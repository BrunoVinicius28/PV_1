class Jogo {
    String nome;
    double preco;
    boolean temDlc;

    public Jogo(String nome, double preco, boolean temDlc) {
        nome = nome;
        preco = preco;
        temDlc = temDlc;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public boolean temDlc() {
        return temDlc;
    }
}




